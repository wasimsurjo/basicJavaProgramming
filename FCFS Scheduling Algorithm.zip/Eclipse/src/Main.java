public class Main 

//WASIM MAHMUD SURJO
//ID: 19341019
//NO PLAGIARISM
{
    public static void main(String[] args) throws InterruptedException {
        Runner runner= new Runner();
        runner.inputValue();
        runner.runProcesses();
        runner.printResult();
    }
}
