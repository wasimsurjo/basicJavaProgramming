import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

//WASIM MAHMUD SURJO
//ID: 19341019
//NO PLAGIARISM

public class Runner {
    List<Process> processes = new ArrayList<>();
    int processCount = 0;
    int timeline = 0;
    
    
    Scanner sc=new Scanner(System.in);

    public void inputValue() {
        System.out.println("Select Number of Process:");
        // TODO: Take input for the total number of processes
        int proc=sc.nextInt();
        
        for(int i=0;i<proc;i++) {
        System.out.println("Process => "+processCount);	
        // TODO: Take input for the process time of each process
        System.out.println("Burst Time?");
        int bur=sc.nextInt();
        System.out.println("Arrive Time?");
        int Arv=sc.nextInt();
        
        Process p=new Process(processCount,bur,Arv);
        processes.add(p);
        processCount++;
    }}

    public void runProcesses() throws InterruptedException {
        // TODO: Calculate WaitT, StartT, EndT for each process
    	
    	Process temp=processes.get(0);
		timeline=timeline+temp.getArv();				
	        	
    	for(int i=0;i<processCount;i++) {
    		temp=processes.get(i);				
    	    temp.setStartTime(timeline);
    	    temp.setEndTime(temp.getStartTime()+temp.getTime());
    	    temp.setWaitTime(temp.getStartTime()-temp.getArv());
    	    timeline=timeline+temp.getTime();
    	    
    	    //Can Also Be Done By Do While Loop
    	}
    }

    public void printResult() {
        System.out.println("------------------------------------");
        System.out.println("Id  Time  WaitT  ArvTime  StartT  EndT");
        System.out.println("------------------------------------");
        // TODO: Print the result accordingly
    	for(int i=0;i<processCount;i++) {
    		Process temp=processes.get(i);
    		System.out.println(temp.getId()+"   "+temp.getTime()+"   "+temp.getWaitTime()+"      "+temp.getArv()+"      "+temp.getStartTime()+"      "+temp.getEndTime());
    	}
    }
}
